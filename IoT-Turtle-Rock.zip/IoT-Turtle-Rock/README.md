# IoT-Turtle-Rock

### Intrusion Detection System for IoT Devices: DDoS Detection

**Members:** Cody C Ebert, Christopher Henderson, Dylan Secreast
